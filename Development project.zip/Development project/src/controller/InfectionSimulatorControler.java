package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.community;
import model.map;
import view.CommunityDataInput;
import view.DiseaseDataInputPane;
import view.GraphPane;
import view.InfectionSimulatorRootPane;
import view.InfectiousDiseaseSimulatorMenuBar;
import view.OutputOnePane;
import view.PolicyDataInputPane;
import view.TravelDataInputPane;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Random;
import java.util.regex.Pattern;
import java.lang.Math;

public class InfectionSimulatorControler {
	private InfectionSimulatorRootPane view;
	private static map model;

	private DiseaseDataInputPane ddip;
	private OutputOnePane oop;
	private CommunityDataInput cdi,cdi2,cdi3,cdi4;
	private InfectiousDiseaseSimulatorMenuBar idsmb;

	//private ObservableList<String> op1;
	/*
	private double infectProb;
	private double immunity;
	private static int daysInfected;
	private static int day;
	private double deathChance;
	*/
	
	private ArrayList<community> comies= new ArrayList<community>();
	private TravelDataInputPane tdi;
	private PolicyDataInputPane pdi;
	private GraphPane gp;

	public InfectionSimulatorControler(InfectionSimulatorRootPane view, map model) {
		// initialise view and model fields
		this.view = view;
		this.model = model;
		/*
		immunity = 90;
		daysInfected = 14;
		deathChance = 1;
		infectProb = 18;
		day=0;
		*/

		//op1 = FXCollections.observableArrayList();

		ddip = view.getDDID();
		oop = view.getOOP();
		cdi = view.getCDI();
		cdi2 = view.getCDI2();
		cdi3 = view.getCDI3();
		cdi4 = view.getCDI4();
		tdi= view.getTDI();
		idsmb=view.getIDSMB();
		pdi=view.getPDI();
		gp=view.getGP();

		this.attachEventHandlers();
	}

	private void attachEventHandlers() {
		ddip.addDiseaseDataInputHandler(new ChangeDiseaseData());
		oop.addSimulateDiseaseHandler(new SimulateFull());
		// cdi.addNewComHandler(new NewCom());
		cdi.addComDataInputHandler(new ChangeMap());
		tdi.addCreateLinksHandler(new addTravelLinks());
		oop.addSimulate1Handler(new SimulatePart1());
		oop.addSimulate10Handler(new SimulatePart10());
		oop.addSimulate50Handler(new SimulatePart50());
		oop.addSimulate100Handler(new SimulatePart100());
		idsmb.addSaveHandler(new saveFile());
		idsmb.addLoadHandler(new loadFile());
		idsmb.addExitHandler(e -> System.exit(0));
		idsmb.addAboutHandler(new aboutBox());
		cdi2.addComDataInputHandler(new ChangeMap());
		cdi3.addComDataInputHandler(new ChangeMap());
		cdi4.addComDataInputHandler(new ChangeMap());
		pdi.addCreatePolicyHandler(new CreatePolicy());
	}

	private class CreatePolicy implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			String c1toc2 = pdi.getC1toC2();
			String c1toc3 = pdi.getC1toC3();
			String c1toc4 = pdi.getC1toC4();
			String c2toc1 = pdi.getC2toC1();

			Double c1 = stringToDoublePer(c1toc2);
			Double c2 = stringToDoublePer(c1toc3);
			Double c3 = stringToDoublePer(c1toc4);
			Double c4 = stringToDoublePer(c2toc1);
			if ((c1 != null) && (c2 != null) && (c3 != null) && (c4 != null)) {
				model.addPolicy(c1, c2, c3, c4);
			}
		}
	}

	private class SimulatePart1 implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			System.out.println("press");
			System.out.println("day=" + model.getDay() + ", infected = " + model.getNumbInfect() + ", dead = "
					+ model.getNumbDead() + ", uninfected = " + model.getNumbNonInfect());
			model.setDay(model.getDay()+1);
			oop.addToOut1("day=" + model.getDay() + ", infected = " + model.getNumbInfect() + ", dead = " + model.getNumbDead()
					+ ", uninfected = " + model.getNumbNonInfect());
			oop.addToOut2("day=" +model.getDay() + ", infected = " + model.getComies().get(0).getInfected() + ", dead = "
					+ model.getComies().get(0).getDead() + ", uninfected = "
					+ model.getComies().get(0).getNonInfected());
			oop.addToOut3("day=" + model.getDay() + ", infected = " + model.getComies().get(1).getInfected() + ", dead = "
					+ model.getComies().get(1).getDead() + ", uninfected = "
					+ model.getComies().get(1).getNonInfected());
			oop.addToOut4("day=" + model.getDay() + ", infected = " + model.getComies().get(2).getInfected() + ", dead = "
					+ model.getComies().get(2).getDead() + ", uninfected = "
					+ model.getComies().get(2).getNonInfected());
			oop.addToOut5("day=" + model.getDay() + ", infected = " + model.getComies().get(3).getInfected() + ", dead = "
					+ model.getComies().get(3).getDead() + ", uninfected = "
					+ model.getComies().get(3).getNonInfected());
			
			gp.addToTotInf(model.getDay(), model.getNumbInfect());
			gp.addToc1Inf(model.getDay(), model.getComies().get(0).getInfected());
			gp.addToc2Inf(model.getDay(), model.getComies().get(1).getInfected());
			gp.addToc3Inf(model.getDay(), model.getComies().get(2).getInfected());
			gp.addToc4Inf(model.getDay(), model.getComies().get(3).getInfected());

			gp.addToTotd(model.getDay(), model.getNumbDead());
			gp.addToc1d(model.getDay(), model.getComies().get(0).getDead());
			gp.addToc2d(model.getDay(), model.getComies().get(1).getDead());
			gp.addToc3d(model.getDay(), model.getComies().get(2).getDead());
			gp.addToc4d(model.getDay(), model.getComies().get(3).getDead());
			model.nextDay(model.getInfectionProb(), model.getImmunity());
			System.out.println(model.getNumbInfect());

		}
	}
	
	private class SimulatePart10 implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			System.out.println("press");
			for (int i = 0; i < 10; i++) {
				System.out.println("day="+model.getDay()+", infected = " + model.getNumbInfect() + ", dead = " + model.getNumbDead()
				+ ", uninfected = " + model.getNumbNonInfect());
				model.setDay(model.getDay()+1);
				oop.addToOut1("day="+model.getDay()+", infected = " + model.getNumbInfect() + ", dead = " + model.getNumbDead()
						+ ", uninfected = " + model.getNumbNonInfect());
				oop.addToOut2("day="+model.getDay()+", infected = " + model.getComies().get(0).getInfected() + ", dead = " + model.getComies().get(0).getDead() + ", uninfected = " + model.getComies().get(0).getNonInfected());
				oop.addToOut3("day="+model.getDay()+", infected = " + model.getComies().get(1).getInfected() + ", dead = " + model.getComies().get(1).getDead() + ", uninfected = " + model.getComies().get(1).getNonInfected());
				oop.addToOut4("day="+model.getDay()+", infected = " + model.getComies().get(2).getInfected() + ", dead = " + model.getComies().get(2).getDead() + ", uninfected = " + model.getComies().get(2).getNonInfected());
				oop.addToOut5("day="+model.getDay()+", infected = " + model.getComies().get(3).getInfected() + ", dead = " + model.getComies().get(3).getDead() + ", uninfected = " + model.getComies().get(3).getNonInfected());
				gp.addToTotInf(model.getDay(), model.getNumbInfect());
				gp.addToc1Inf(model.getDay(), model.getComies().get(0).getInfected());
				gp.addToc2Inf(model.getDay(), model.getComies().get(1).getInfected());
				gp.addToc3Inf(model.getDay(), model.getComies().get(2).getInfected());
				gp.addToc4Inf(model.getDay(), model.getComies().get(3).getInfected());

				gp.addToTotd(model.getDay(), model.getNumbDead());
				gp.addToc1d(model.getDay(), model.getComies().get(0).getDead());
				gp.addToc2d(model.getDay(), model.getComies().get(1).getDead());
				gp.addToc3d(model.getDay(), model.getComies().get(2).getDead());
				gp.addToc4d(model.getDay(), model.getComies().get(3).getDead());
				model.nextDay(model.getInfectionProb(), model.getImmunity());
				System.out.println(model.getNumbInfect());
				
			}
		}
	}

	private class SimulatePart50 implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			System.out.println("press");
			for (int i = 0; i < 50; i++) {
				System.out.println("day="+model.getDay()+", infected = " + model.getNumbInfect() + ", dead = " + model.getNumbDead()
				+ ", uninfected = " + model.getNumbNonInfect());
				model.setDay(model.getDay()+1);
				oop.addToOut1("day="+model.getDay()+", infected = " + model.getNumbInfect() + ", dead = " + model.getNumbDead()
						+ ", uninfected = " + model.getNumbNonInfect());
				oop.addToOut2("day="+model.getDay()+", infected = " + model.getComies().get(0).getInfected() + ", dead = " + model.getComies().get(0).getDead() + ", uninfected = " + model.getComies().get(0).getNonInfected());
				oop.addToOut3("day="+model.getDay()+", infected = " + model.getComies().get(1).getInfected() + ", dead = " + model.getComies().get(1).getDead() + ", uninfected = " + model.getComies().get(1).getNonInfected());
				oop.addToOut4("day="+model.getDay()+", infected = " + model.getComies().get(2).getInfected() + ", dead = " + model.getComies().get(2).getDead() + ", uninfected = " + model.getComies().get(2).getNonInfected());
				oop.addToOut5("day="+model.getDay()+", infected = " + model.getComies().get(3).getInfected() + ", dead = " + model.getComies().get(3).getDead() + ", uninfected = " + model.getComies().get(3).getNonInfected());
				gp.addToTotInf(model.getDay(), model.getNumbInfect());
				gp.addToc1Inf(model.getDay(), model.getComies().get(0).getInfected());
				gp.addToc2Inf(model.getDay(), model.getComies().get(1).getInfected());
				gp.addToc3Inf(model.getDay(), model.getComies().get(2).getInfected());
				gp.addToc4Inf(model.getDay(), model.getComies().get(3).getInfected());

				gp.addToTotd(model.getDay(), model.getNumbDead());
				gp.addToc1d(model.getDay(), model.getComies().get(0).getDead());
				gp.addToc2d(model.getDay(), model.getComies().get(1).getDead());
				gp.addToc3d(model.getDay(), model.getComies().get(2).getDead());
				gp.addToc4d(model.getDay(), model.getComies().get(3).getDead());
				model.nextDay(model.getInfectionProb(), model.getImmunity());
				System.out.println(model.getNumbInfect());
				
			}
		}
	}

	private class SimulatePart100 implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			System.out.println("press");
			for (int i = 0; i < 100; i++) {
				System.out.println("day="+model.getDay()+", infected = " + model.getNumbInfect() + ", dead = " + model.getNumbDead()
				+ ", uninfected = " + model.getNumbNonInfect());
				model.setDay(model.getDay()+1);
				oop.addToOut1("day="+model.getDay()+", infected = " + model.getNumbInfect() + ", dead = " + model.getNumbDead()
						+ ", uninfected = " + model.getNumbNonInfect());
				oop.addToOut2("day="+model.getDay()+", infected = " + model.getComies().get(0).getInfected() + ", dead = " + model.getComies().get(0).getDead() + ", uninfected = " + model.getComies().get(0).getNonInfected());
				oop.addToOut3("day="+model.getDay()+", infected = " + model.getComies().get(1).getInfected() + ", dead = " + model.getComies().get(1).getDead() + ", uninfected = " + model.getComies().get(1).getNonInfected());
				oop.addToOut4("day="+model.getDay()+", infected = " + model.getComies().get(2).getInfected() + ", dead = " + model.getComies().get(2).getDead() + ", uninfected = " + model.getComies().get(2).getNonInfected());
				oop.addToOut5("day="+model.getDay()+", infected = " + model.getComies().get(3).getInfected() + ", dead = " + model.getComies().get(3).getDead() + ", uninfected = " + model.getComies().get(3).getNonInfected());
				gp.addToTotInf(model.getDay(), model.getNumbInfect());
				gp.addToc1Inf(model.getDay(), model.getComies().get(0).getInfected());
				gp.addToc2Inf(model.getDay(), model.getComies().get(1).getInfected());
				gp.addToc3Inf(model.getDay(), model.getComies().get(2).getInfected());
				gp.addToc4Inf(model.getDay(), model.getComies().get(3).getInfected());

				gp.addToTotd(model.getDay(), model.getNumbDead());
				gp.addToc1d(model.getDay(), model.getComies().get(0).getDead());
				gp.addToc2d(model.getDay(), model.getComies().get(1).getDead());
				gp.addToc3d(model.getDay(), model.getComies().get(2).getDead());
				gp.addToc4d(model.getDay(), model.getComies().get(3).getDead());
				model.nextDay(model.getInfectionProb(), model.getImmunity());
				System.out.println(model.getNumbInfect());
				
			}
		}
	}
	
	private class SimulateFull implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			System.out.println("press");
			while (model.getNumbInfect() > 0) {
				System.out.println("day="+model.getDay()+", infected = " + model.getNumbInfect() + ", dead = " + model.getNumbDead()
				+ ", uninfected = " + model.getNumbNonInfect());
				model.setDay(model.getDay()+1);
				oop.addToOut1("day="+model.getDay()+", infected = " + model.getNumbInfect() + ", dead = " + model.getNumbDead()
						+ ", uninfected = " + model.getNumbNonInfect());
				oop.addToOut2("day="+model.getDay()+", infected = " + model.getComies().get(0).getInfected() + ", dead = " + model.getComies().get(0).getDead() + ", uninfected = " + model.getComies().get(0).getNonInfected());
				oop.addToOut3("day="+model.getDay()+", infected = " + model.getComies().get(1).getInfected() + ", dead = " + model.getComies().get(1).getDead() + ", uninfected = " + model.getComies().get(1).getNonInfected());
				oop.addToOut4("day="+model.getDay()+", infected = " + model.getComies().get(2).getInfected() + ", dead = " + model.getComies().get(2).getDead() + ", uninfected = " + model.getComies().get(2).getNonInfected());
				oop.addToOut5("day="+model.getDay()+", infected = " + model.getComies().get(3).getInfected() + ", dead = " + model.getComies().get(3).getDead() + ", uninfected = " + model.getComies().get(3).getNonInfected());
				gp.addToTotInf(model.getDay(), model.getNumbInfect());
				gp.addToc1Inf(model.getDay(), model.getComies().get(0).getInfected());
				gp.addToc2Inf(model.getDay(), model.getComies().get(1).getInfected());
				gp.addToc3Inf(model.getDay(), model.getComies().get(2).getInfected());
				gp.addToc4Inf(model.getDay(), model.getComies().get(3).getInfected());

				gp.addToTotd(model.getDay(), model.getNumbDead());
				gp.addToc1d(model.getDay(), model.getComies().get(0).getDead());
				gp.addToc2d(model.getDay(), model.getComies().get(1).getDead());
				gp.addToc3d(model.getDay(), model.getComies().get(2).getDead());
				gp.addToc4d(model.getDay(), model.getComies().get(3).getDead());
				model.nextDay(model.getInfectionProb(), model.getImmunity());
				System.out.println(model.getNumbInfect());
				
			}
		}
	}

	private class ChangeDiseaseData implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			System.out.println("disease button clicked");
			String error = "";

			try {
				int daysInfectedInput = Integer.parseInt(ddip.getDaysInfected());
				if (daysInfectedInput <= 0) {
					error += "Days infected is too small, must be >0\n";
				}
			} catch (NumberFormatException ex) {
				error += "Days infected is not an int\n";
				System.out.println(error);
			}

			try {
				Double ImmunityInput = Double.parseDouble(ddip.getImmunityAfetrInfection());
				if (ImmunityInput <= 0) {
					error += "immunity is too small, must be >0\n";
				} else if (ImmunityInput > 100) {
					error += "immunity is too big, must less than or equil to 100\n";
				}

			} catch (NumberFormatException ex) {
				error += "immunity is not a number/n";
				System.out.println(error);
			}

			try {
				Double InputInfect = Double.parseDouble(ddip.getR0());
				if (InputInfect < 1) {
					error += "R0 is too small, must be >=1\n";
				} else if (InputInfect > 100) {
					error += "R0 is too big, must less than or equil to 100\n";
				}

			} catch (NumberFormatException ex) {
				error += "R0 is not a number/n";
				System.out.println(error);
			}

			try {
				Double InputDeath = Double.parseDouble(ddip.getDeathChance());
				if (InputDeath < 0) {
					error += "chance of death is too small, must be >=0\n";
				} else if (InputDeath > 100) {
					error += "chance of death is too big, must less than or equil to 100\n";
				}

			} catch (NumberFormatException ex) {
				error += "chance of death is not a number/n";
				System.out.println(error);
			}

			if (error == "") {
				model.setDaysInfected( Integer.parseInt(ddip.getDaysInfected()));
				double tempInfProb = 50.53 * Math.pow((Double.parseDouble(ddip.getR0()) / model.getDaysInfected()), 0.4848);
				model.setInfectionProb(tempInfProb);// see writing for explenation of this maths
				System.out.println(tempInfProb);
				model.setImmunity(Double.parseDouble(ddip.getImmunityAfetrInfection()));
				model.setDeathChance(Double.parseDouble(ddip.getDeathChance()));

			} else {
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("Error");
				alert.setHeaderText("Input Error");
				alert.setContentText(error);
				alert.showAndWait();

			}
		}
	}

	private class ChangeMap implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			community com1 = getMapDetails(cdi);
			community com2 = getMapDetails(cdi2);
			community com3 = getMapDetails(cdi3);
			community com4 = getMapDetails(cdi4);
			if ((com1 != null) && (com2 != null) && (com3 != null) && (com4 != null)) {
				double infectProb=model.getInfectionProb();
				double immunity=model.getImmunity();
				int daysInfected=model.getDaysInfected();
				double deathChance=model.getDeathChance();
				model = new map(com1, com2, com3, com4, infectProb, immunity, daysInfected, deathChance);
			}
			//oop.resetOut1();

		}
	}

	private class addTravelLinks implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			String c1toc2= tdi.getC1toC2();
			String c1toc3= tdi.getC1toC3();
			String c1toc4= tdi.getC1toC4();
			String c2toc1 =tdi.getC2toC1();
			
			Double c1= stringToDoublePer(c1toc2);
			Double c2= stringToDoublePer(c1toc3);
			Double c3= stringToDoublePer(c1toc4);
			Double c4 =stringToDoublePer(c2toc1);
			if ((c1 != null) && (c2 != null) && (c3 != null) && (c4 != null)) {
				model.addTravelLink(c1, c2, c3, c4);
			}
			
		}
	}

	private class saveFile implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			try {
				 
	            FileOutputStream fileOut = new FileOutputStream("savedMap");
	            ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
	            objectOut.writeObject(model);
	            objectOut.close();
	            System.out.println("The Object  was succesfully written to a file");
	 
	        } catch (Exception ex) {
	            ex.printStackTrace();
	        }
		}
	}
	private class loadFile implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			try {
				 
	            //Read from the stored file
	            FileInputStream fileInputStream = new FileInputStream(new File("savedMap"));
	            ObjectInputStream input = new ObjectInputStream(fileInputStream);
	            map tempMap = (map) input.readObject();
	            model=tempMap;
	            input.close();
	        } catch (FileNotFoundException h) {
	            h.printStackTrace();
	        } catch (IOException h) {
	            h.printStackTrace();
	        } catch (ClassNotFoundException h) {
	            h.printStackTrace();
	        }
		}
	}
	
	private class aboutBox implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setResizable(true);
			alert.setTitle("About");
			alert.setHeaderText("About");
			alert.setContentText("this about box can be resized to show more information.\r\n"
					+ "instructions for use of infectious disease simulator tool:\r\n"
					+ "\r\n"
					+ "to run simulation with default values go to output page and press any simulation button\r\n"
					+ "\r\n"
					+ "default values for disease are: \r\n"+
					"		infectProb=18.0\r\n" + 
					"		immunity=90.0\r\n" + 
					"		daysInfected=14\r\n" +
					"		deathChance=1.0\r\n"+
					"		(this is intended to replicate covid-19 however death chance and immunity are higher than covid-19 is estimated to be \r\n"
					+"default community will have 1000 people, all unvaccinated and with no vunerabilities:\r\n"
					+ "\r\n"
					+ "to reset the tool close and reopen\r\n"
					+ "\r\n"
					+ "input clarification\r\n"+
					"		R0 (reproductive number)= for every infection what is the expected number of new people infected (recomend 2-5 since most diseases are within that bound)\r\n" + 
					"		days someone is infected = recomend value 7-21 range. small values may make infected recover before spread, high may cause long simulation\r\n" + 
					"		immunity after infection= recomend high value to prevent possibility of infinate loops\r\n" +
					"		age realted vunerability and none age related vunerability = since there are various factors that influence vunerability i deceided to split these into 2 groups"
					+ "these groups work sililarly and can overlap, however age uses a persons age to increase vunerability and non-age uses an indepenant randomiser\r\n"+
					"		% of population... = uses a randomiser to select random people\r\n"
					+ "		death/infection muliplier= multiplies the chance of death/spread of infection\r\n"
					+ "		infected population of ... = the starting population that is infected (not a %). recomended using >1 to maximise accuracy\r\n"
					+ "		probabillity of infection spreading from...= the probability that an infection will leve the community and travel to a differnt community\r\n"
					+ "		mitigation effectiveness = the multiplier of the probability of infection. most policies will reduce, so whould be between 0 and 1 (full lockdown estimated to be 0.5). however you can increase the likelyhood by making it >1");
			alert.showAndWait();
		}
	}
	
	private static Double stringToDoublePer(String str) {
		String error = "";
	
		try {
			Double ImmunityInput = Double.parseDouble(str);
			if (ImmunityInput < 0) {
				error += ""+str+" is too small, must be >=0\n";
			} else if (ImmunityInput > 100) {
				error += ""+str+" is too big, must less than or equil to 100\n";
			}
		}catch (NumberFormatException ex) {
			error += ""+str+" is not an int\n";
			System.out.println(error);
		}
		if (error == "") {
			return Double.parseDouble(str);

		} else {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Error");
			alert.setHeaderText("Input Error");
			alert.setContentText(error);
			alert.showAndWait();
			return null;

		}
	}

	private static Double findInfectProb(Double Prob, Double previousProb, Double target) {
		double n = 0;
		for (int i = 0; i < 100000; i++) {

			n += spread(0, Prob);
		}
		double differnce = 0;
		if (((target - n) > 0)) {// too small
			differnce = Math.abs((Prob - previousProb) / 2);
			if (differnce > 0.01) {
				Prob = findInfectProb(Prob + differnce, Prob, target);
			}
			// findInfectProb(target, (target-n));
		} else if (((target - n) < 0)) {// too big
			differnce = Math.abs((Prob - previousProb) / 2);
			if (differnce > 0.01) {
				Prob = findInfectProb(Prob - differnce, Prob, target);
			}
			// findInfectProb(target, (target-n));
		}
		return Prob;
	}

	private static int spread(int newInfect, double prob) {
		if (prob > new Random().nextDouble()*100) {
			newInfect += 1;
			newInfect = spread(newInfect, prob);
		}

		return newInfect;
	}

	
	private static community getMapDetails(CommunityDataInput comIn) {
		System.out.println("disease button clicked");
		String error = "";

		try {
			int pop = Integer.parseInt(comIn.getC1Pop());
			if (pop < 0) {
				error += "population is too small, must be >=0\n";
			}
		} catch (NumberFormatException ex) {
			error += "population is not an int\n";
			System.out.println(error);
		}

		try {
			Double ImmunityInput = Double.parseDouble(comIn.getC1VacPer());
			if (ImmunityInput < 0) {
				error += "% vacinated is too small, must be >=0\n";
			} else if (ImmunityInput > 100) {
				error += "% vacinated is too big, must less than or equil to 100\n";
			}

		} catch (NumberFormatException ex) {
			error += "% vacinated is not a number/n";
			System.out.println(error);
		}

		try {
			Double InputInfect = Double.parseDouble(comIn.getC1VacEff());
			if (InputInfect <= 0) {
				error += "vaccine effectiveness is too small, must be >0\n";
			} else if (InputInfect > 100) {
				error += "vaccine effectiveness is too big, must less than or equil to 100\n";
			}

		} catch (NumberFormatException ex) {
			error += "vaccine effectiveness is not a number/n";
			System.out.println(error);
		}

		try {
			Double InputAOV = Double.parseDouble(comIn.getC1AOV());
			if (InputAOV <= 0) {
				error += "age of vunerability is too small, must be >0\n";
			} else if (InputAOV > 100) {
				error += "age of vulnerability is too big, must less than or equil to 100\n";
			}

		} catch (NumberFormatException ex) {
			error += "age of vulnerability is not a number/n";
			System.out.println(error);
		}
		try {
			Double InputADM = Double.parseDouble(comIn.getC1ADM());
			if (InputADM <= 0) {
				error += "age death multiplier is too small, must be >0\n";
			}

		} catch (NumberFormatException ex) {
			error += "age death multiplier is not a number/n";
			System.out.println(error);
		}
		try {
			Double InputPV = Double.parseDouble(comIn.getC1PV());
			if (InputPV < 0) {
				error += "percent vunerable is too small, must be >=0\n";
			} else if (InputPV > 100) {
				error += "percent vunerable is too big, must less than or equil to 100\n";
			}

		} catch (NumberFormatException ex) {
			error += "percent vunerable is not a number/n";
			System.out.println(error);
		}
		try {
			Double InputIV = Double.parseDouble(comIn.getC1IV());
			if (InputIV <= 0) {
				error += "increase in vunerablity is too small, must be >0\n";
			}

		} catch (NumberFormatException ex) {
			error += "increase in vunerablity is not a number/n";
			System.out.println(error);
		}
		try {
			Double InputIM = Double.parseDouble(comIn.getC1IM());
			if (InputIM <= 0) {
				error += "infection multiplier is too small, must be >0\n";
			}

		} catch (NumberFormatException ex) {
			error += "infection multiplier is not a number/n";
			System.out.println(error);
		}
		try {
			int InputInf = Integer.parseInt(comIn.getC1Inf());
			if (InputInf < 0) {
				error += "number infected is too small, must be >=0\n";
			}
			if (InputInf > Integer.parseInt(comIn.getC1Pop())) {
				error += "number infected is bigger than population\n";
			}

		} catch (NumberFormatException ex) {
			error += "number infected is not a number/n";
			System.out.println(error);
		}

		if (error == "") {
			community tempCom= new community(Integer.parseInt(comIn.getC1Pop()), Integer.parseInt(comIn.getC1Inf()),
					model.getDaysInfected(), Double.parseDouble(comIn.getC1VacPer()), Double.parseDouble(comIn.getC1VacEff()),
					Double.parseDouble(comIn.getC1AOV()), Double.parseDouble(comIn.getC1ADM()), Double.parseDouble(comIn.getC1PV()),
					Double.parseDouble(comIn.getC1IV()), Double.parseDouble(comIn.getC1IM()));
			return tempCom;

		} else {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Error");
			alert.setHeaderText("Input Error");
			alert.setContentText(error);
			alert.showAndWait();
			return null;

		}
	}
}
