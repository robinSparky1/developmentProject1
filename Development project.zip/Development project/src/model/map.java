package model;

import java.util.ArrayList;
import java.util.Random;

public class map {
	private ArrayList<community> comies = new ArrayList<community>();
	private double infectProb;
	private double immunity;
	private static int daysInfected;
	private static int day;
	private double deathChance;

	public map() {
		infectProb = 18.0;
		immunity = 90.0;
		daysInfected = 14;
		day = 0;
		deathChance = 1.0;
		System.out.println("map");
		community com1 = new community();
		community com2 = new community();
		community com3 = new community();
		community com4 = new community();
		comies.add(com1);
		comies.add(com2);
		comies.add(com3);
		comies.add(com4);
		System.out.println("size" + comies.size());
		day = 1;
	}

	public map(community com1, community com2, community com3, community com4, double infectProb, double immunity,
			int daysInfected, double deathChance) {
		System.out.println("map");
		comies = new ArrayList<community>();
		comies.add(com1);
		comies.add(com2);
		comies.add(com3);
		comies.add(com4);
		day = 1;
		System.out.println("size" + comies.size());
		System.out.println("im" + immunity);
	}

	public double getInfectionProb() {
		return infectProb;
	}

	public double getImmunity() {
		return immunity;
	}

	public double getDeathChance() {
		return deathChance;
	}

	public int getDaysInfected() {
		return daysInfected;
	}

	public int getDay() {
		return day;
	}

	public void setInfectionProb(double newInfectProb) {
		infectProb = newInfectProb;
	}

	public void setImmunity(double newImmunity) {
		immunity = newImmunity;
	}

	public void setDeathChance(double newDeathChance) {
		deathChance = newDeathChance;
	}

	public void setDaysInfected(int newDaysInfected) {
		daysInfected = newDaysInfected;
	}

	public void setDay(int newDay) {
		day = newDay;
	}

	public ArrayList<community> getComies() {
		return comies;
	}

	public int getNumbDead() {
		int numberInfect = 0;
		for (int counter = 0; counter < comies.size(); counter++) {
			numberInfect += comies.get(counter).getDead();
		}
		return numberInfect;
	}

	public int getNumbNonInfect() {
		int numberInfect = 0;
		for (int counter = 0; counter < comies.size(); counter++) {
			numberInfect += comies.get(counter).getNonInfected();
		}
		return numberInfect;
	}

	public ArrayList<community> getCommies() {
		return comies;
	}

	public int getNumbInfect() {
		int numberInfect = 0;
		for (int counter = 0; counter < comies.size(); counter++) {
			numberInfect += comies.get(counter).getInfected();
		}
		return numberInfect;
	}

	public void addPolicy(double spreTo1, double spreTo2, double spreTo3, double spreTo4) {
		comies.get(0).setPolicy(spreTo1);
		comies.get(1).setPolicy(spreTo2);
		comies.get(2).setPolicy(spreTo3);
		comies.get(3).setPolicy(spreTo4);
	}

	public void addTravelLink(double spreTo1, double spreTo2, double spreTo3, double spreTo4) {
		comies.get(0).setTravelLinks(spreTo1);
		comies.get(1).setTravelLinks(spreTo2);
		comies.get(2).setTravelLinks(spreTo3);
		comies.get(3).setTravelLinks(spreTo4);
	}

	public void nextDay(double probability, double newImmune) {
		for (int counter = 0; counter < comies.size(); counter++) {
		}
		for (int counter = 0; counter < comies.size(); counter++) {
			int exSpread = comies.get(counter).nextDay(probability, newImmune);
			while (exSpread > 0) {
				int randCom = new Random().nextInt(4);
				comies.get(randCom).infectRanPeo(1);
				exSpread--;
			}
		}
	}
}
