package model;

import java.util.ArrayList;
import java.util.Random;

public class community {
	private ArrayList<person> people = new ArrayList<person>();
	private double exSpread;
	private double ifm;
	
	
	public community () {
		ifm=1.0;
		exSpread=0;
		System.out.println("com");
		for (int i=0; i<1000;i++) {
			int randAge = new Random().nextInt(100);
			System.out.println(randAge);
			person newPerson = new person(randAge);
			people.add(newPerson);
		}
		people.get(0).setInfect(14);
		
	}
	
	public community (int pop, int infPop, int dayInf, double vacPer, double vacEff, double ageOfVun, double ageMult, double vunPer, double vunMult, double InfMult) {
		System.out.println("com");
		exSpread=0;
		ifm=InfMult;
		Boolean everyone = (pop<=infPop);
		for (int i=0; i<pop;i++) {
			int randAge = new Random().nextInt(100);
			double randVac = new Random().nextDouble()*100;//change this
			double randVun = new Random().nextDouble()*100;//change this
			System.out.println(randAge);
			person newPerson = new person(randAge);
			if (randVac<vacPer) {newPerson.setImmunity(vacEff);}
			if (everyone){ newPerson.setInfect(dayInf);}//CHANGE THIS
			if (randVun<vunPer) {newPerson.multMorbid(ageMult);}
			newPerson.multInf(InfMult);
			people.add(newPerson);
		}
		for (int i=0; i<infPop;i++) {people.get(i).setInfect(dayInf);}
		
	}
	public ArrayList<person> getPeople(){
		return people;
	}

	public int getDead() {

		int numberDead = 0;
		for (int counter = 0; counter < people.size(); counter++) {
			if (!people.get(counter).getAlive()) {
				numberDead += 1;

			}
		}
		return numberDead;
	}

	public int getNonInfected() {
		
		int numberNotInfect=0;
		for (int counter = 0; counter < people.size(); counter++) {
			if(people.get(counter).getAlive()) {
				if (people.get(counter).getDaysLeft()==0) {
				numberNotInfect+=1;
				} 
			}
		}
		return numberNotInfect;
	}
	
	public int getSuseptable() {

		int numberUnInfect = 0;
		for (int counter = 0; counter < people.size(); counter++) {
			if (people.get(counter).getAlive()) {
				if (people.get(counter).getDaysLeft() == 0) {
					if (!people.get(counter).getBeenInfect()) {
						numberUnInfect += 1;
					}
				}
			}
		}
		return numberUnInfect;
	}
	
	
	public int getInfected() {
		
		int numberInfect=0;
		for (int counter = 0; counter < people.size(); counter++) {
			if(people.get(counter).getAlive()) {
				if (people.get(counter).getDaysLeft()>0) {
				numberInfect+=1;
				} 
			}
		}
		return numberInfect;
	}
	
	public void setPolicy(double polMod) {
		for (person temPerson : people) {
			temPerson.setInfMulti(polMod*ifm);
		}
	}
	
	public void setTravelLinks(double newExSpread) {
		
		exSpread=newExSpread;
	}
	
	public void infectRanPeo(int newInfect) {
		if (newInfect>people.size()-1) {newInfect=people.size()-1;}
		for (int x = 0; x < newInfect; x++) {
			int ranSelect = new Random().nextInt(people.size());
			if (people.get(ranSelect).getAlive()) {
				if (people.get(ranSelect).getImmune()<new Random().nextInt(100)) {
					people.get(ranSelect).setInfect(14);//CHANGE THIS
				}
			}
			
		}
	}
	
	public int nextDay(double probability, double newImmune) {
		System.out.println("newday com");
		int spreadOut = 0;
		for (int counter = 0; counter < people.size(); counter++) {
			int newInfect = people.get(counter).nextDay(probability, newImmune);
			if (newInfect>people.size()-1) {newInfect=people.size()-1;}
			for (int x = 0; x < newInfect; x++) {
				int ranSelect = new Random().nextInt(people.size());
				double ranExSpread = new Random().nextDouble()*100;
				while (ranSelect==counter) {
					ranSelect = new Random().nextInt(people.size());
					
				}
				if (ranExSpread<exSpread) {
					System.out.println("travel");
					spreadOut++;
				}else if (people.get(ranSelect).getAlive()) {
					if (people.get(ranSelect).getImmune()<new Random().nextDouble()*100) {
						people.get(ranSelect).setInfect(14);//CHANGE THIS
					}
				}
				
			}
		}
		return spreadOut;
	}
}
