package model;

import java.util.Random;

public class person {
	// representation of a persons age
	private int age;
	// representation of a persons comorbidities (likelyhood to die)
	private double morbidMultiplier;
	// representation of how long is left in the infection. if >0 then they are
	// infected
	private int daysLeftInfected;
	// the likelyhood of someonbe to resist infection
	private double Immunity;
	// if someone is alive
	private Boolean alive;
	// if someone has been infected
	private Boolean hasBeenInfect;
	// multipiplier for infection
	private double InfMulti;

	public person(int yrs, double morbility, int days, double immune) {
		age = yrs;
		morbidMultiplier = morbility;
		daysLeftInfected = days;
		Immunity = immune;
		alive = true;
		hasBeenInfect = false;
		InfMulti=1;
	}

	public person(int yrs, int mM) {
		age = yrs;
		morbidMultiplier = mM;
		daysLeftInfected = 0;
		Immunity = 0;
		alive = true;
		hasBeenInfect = false;
		InfMulti=1;
	}

	// main constructor
	public person(int yrs) {
		System.out.println("per");
		age = yrs;
		morbidMultiplier = 1;
		daysLeftInfected = 0;
		Immunity = 0;
		alive = true;
		hasBeenInfect = false;
		InfMulti=1;
	}

	// main constructor
	public person() {
		System.out.println("per");
		age = 40;
		morbidMultiplier = 1;
		daysLeftInfected = 0;
		Immunity = 0;
		alive = true;
		hasBeenInfect = false;
		InfMulti=1;
	}

	// get methods
	public Boolean getBeenInfect() {
		return hasBeenInfect;
	}
	public int getAge() {
		return age;
	}

	public double getMorbid() {
		return morbidMultiplier;
	}

	public Boolean getAlive() {
		return alive;
	}

	public double getImmune() {
		return Immunity;
	}

	public int getDaysLeft() {
		return daysLeftInfected;
	}

	// set methods

	public void setDaysLeft(int days) {// DO NOT USE TO MAKE SOMEONE INFECTED
		daysLeftInfected = days;
	}

	public void setAge(int ageNew) {
		age = ageNew;
	}

	public void setImmunity(double im) {
		Immunity = im;
	}

	public void setAlive(boolean aliv) {
		alive = aliv;
	}

	public void setMorbid(double mm) {
		morbidMultiplier = mm;
	}
	public void multMorbid(double mm) {
		morbidMultiplier = mm*morbidMultiplier;
	}
	public void multInf(double mm) {
		InfMulti = mm*InfMulti;
	}
	public void setInfMulti(double mm) {
		InfMulti = mm;
	}
	// person functions

	// infecting someone
	public void setInfect(int days) {// USE THIS FOR INFECTING PEOPLE
		daysLeftInfected = days;
		Immunity = 100;
	}

	// calculating if and how many new people to infect
	private int spread(int newInfect, double prob) {
		if (prob > new Random().nextDouble()*100) {
			newInfect += 1;
			newInfect = spread(newInfect, prob);
		}
		return newInfect;
	}

	// progressing to next day
	public int nextDay(double probability, double newImmune) {
		// if infected
		if (daysLeftInfected > 0) {
			// simulate death posibility
			if (1 * morbidMultiplier > new Random().nextDouble()*100) {// currently too high
				alive = false;
				System.out.println("DEATH!!!!");
			}
			// recover with partial immunity
			if (daysLeftInfected == 1) {
				Immunity = newImmune;
			}
			daysLeftInfected -= 1;
			// find out how many new infections this person creates
			double prob=probability*InfMulti;
			if (prob>99) {
				prob=99;
				System.out.println(""+probability+"!!!warning: infection probability exceeds 99%. has been modified however this may be inaccurate");
			}
			int spr = spread(0, probability*InfMulti);
			return spr;
		}
		return 0;
	}
}
