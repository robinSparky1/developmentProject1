package view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;

public class PolicyDataInputPane extends GridPane {
	private TextField C1ToC2;
	private TextField C1ToC4;
	private TextField C1ToC3;
	private TextField C2ToC1;
	private Button btnCreateLinks;

	public PolicyDataInputPane() {
		// styling
		this.setVgap(15);
		this.setHgap(20);
		this.setAlignment(Pos.CENTER);

		ColumnConstraints column0 = new ColumnConstraints();
		column0.setHalignment(HPos.RIGHT);

		this.getColumnConstraints().addAll(column0);

		// create labels
		Label lblC1ToC2 = new Label("Mitigation effectivenessin community 1");
		Label lblC1ToC3 = new Label("Mitigation effectivenessin community 2");
		Label lblC1ToC4 = new Label("Mitigation effectivenessin community 3");
		Label lblC2ToC1 = new Label("Mitigation effectivenessin community 4");

		// setup text fields
		C1ToC2 = new TextField();
		C1ToC3 = new TextField();
		C1ToC4 = new TextField();
		C2ToC1 = new TextField();

		// initialise create profile button
		btnCreateLinks = new Button("Add Mitigation Policies");
		
		//add controls and labels to container
		this.add(lblC1ToC2, 0, 1);
		this.add(C1ToC2, 1, 1);
		
		this.add(lblC1ToC3, 0, 2);
		this.add(C1ToC3, 1, 2);

		this.add(lblC1ToC4, 0, 3);
		this.add(C1ToC4, 1, 3);
		
		this.add(lblC2ToC1, 0, 4);
		this.add(C2ToC1, 1, 4);
		this.add(btnCreateLinks, 0, 13);
		
	}
	
	public String getC1toC2() {return C1ToC2.getText();}
	public String getC1toC3() {return C1ToC3.getText();}
	public String getC1toC4() {return C1ToC4.getText();}
	public String getC2toC1() {return C2ToC1.getText();}
	
	public void addCreatePolicyHandler(EventHandler<ActionEvent> handler) {
		btnCreateLinks.setOnAction(handler);
	}
}
