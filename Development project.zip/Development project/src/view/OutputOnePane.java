package view;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.layout.GridPane;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.StackPane;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.canvas.*;
import javafx.scene.web.*;
import javafx.scene.Group;
import javafx.application.Application;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

public class OutputOnePane  extends GridPane {
	private ObservableList<String> op1;
	private ListView<String>output1;
	private Button btnSimulateDisease,btnSim1,btnSim10,btnSim50,btnSim100;
	private ObservableList<String> op2;
	private ListView<String> output2;
	private ObservableList<String> op3;
	private ListView<String> output3;
	private ObservableList<String> op4;
	private ListView<String> output4;
	private ObservableList<String> op5;
	private ListView<String> output5;
	public OutputOnePane() {
		op1= FXCollections.observableArrayList("total: data will appear here");
		output1=new ListView<>(op1);
		output1.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		this.add(output1, 0, 2, 3, 3);
		
		op2= FXCollections.observableArrayList("community1: data will appear here");
		output2=new ListView<>(op2);
		output2.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		this.add(output2, 0, 6, 3, 3);
		
		op3= FXCollections.observableArrayList("community2: data will appear here");
		output3=new ListView<>(op3);
		output3.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		this.add(output3, 3, 6, 3, 3);
		
		op4= FXCollections.observableArrayList("community1: data will appear here");
		output4=new ListView<>(op4);
		output4.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		this.add(output4, 0, 9, 3, 3);
		
		op5= FXCollections.observableArrayList("community2: data will appear here");
		output5=new ListView<>(op5);
		output5.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		this.add(output5, 3, 9, 3, 3);
		
		btnSimulateDisease = new Button("simulate untill 0 infections\r\n warning: high R0 or low immunity may cause infinate loop");
		btnSim1=new Button("simulate for 1 day");
		btnSim10=new Button("simulate for 10 day");
		btnSim50=new Button("simulate for 50 day");
		btnSim100=new Button("simulate for 100 day");
		this.add(btnSimulateDisease, 0, 1);
		this.add(btnSim1, 2, 1);
		this.add(btnSim10, 3, 1);
		this.add(btnSim50, 4, 1);
		this.add(btnSim100, 5, 1);
	}
	
	public void addToOut1(String s) {
		output1.getItems().add(s);
	}
	public void addToOut2(String s) {
		output2.getItems().add(s);
	}
	public void addToOut3(String s) {
		output3.getItems().add(s);
	}
	public void addToOut4(String s) {
		output4.getItems().add(s);
	}
	public void addToOut5(String s) {
		output5.getItems().add(s);
	}
	public void addSimulateDiseaseHandler(EventHandler<ActionEvent> handler) {
		btnSimulateDisease.setOnAction(handler);
	}
	public void addSimulate1Handler(EventHandler<ActionEvent> handler) {
		btnSim1.setOnAction(handler);
	}
	public void addSimulate10Handler(EventHandler<ActionEvent> handler) {
		btnSim10.setOnAction(handler);
	}
	public void addSimulate50Handler(EventHandler<ActionEvent> handler) {
		btnSim50.setOnAction(handler);
	}
	public void addSimulate100Handler(EventHandler<ActionEvent> handler) {
		btnSim100.setOnAction(handler);
	}
}
