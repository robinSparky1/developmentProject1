package view;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
public class CommunityDataInput extends GridPane {
	
	private TextField c1Pop, C1VacPer,  C1VacEff, C1AOV, C1ADM, C1PV, C1IV,C1IM,C1Inf;
	private Button btnCreateMap;
	
	public CommunityDataInput(int comNumb) {
		
		//styling
		this.setVgap(15);
		this.setHgap(20);
		this.setAlignment(Pos.CENTER);

		ColumnConstraints column0 = new ColumnConstraints();
		column0.setHalignment(HPos.RIGHT);

		this.getColumnConstraints().addAll(column0);
		
		//create labels
		Label lblC1Pop = new Label("Population of community "+comNumb+": ");
		Label lblC1Infec = new Label("infected Population of community "+comNumb+": ");
		Label lblC1Vaccinated = new Label("Input community "+comNumb+" % of population vaccinated: ");
		Label lblC1VacEffect = new Label("Input community "+comNumb+" % of immunity received from vaccine: ");
		Label lblC1AgeOfVulnerable = new Label("Input community "+comNumb+" age which is considered a co-morbidity: ");
		Label lblC1AOVDeathMultiplier = new Label("Input community "+comNumb+" age realted death probability modifier: ");
		Label lblC1PercentVulnerable = new Label("Input community "+comNumb+" % of population with other co-morbidities: ");
		Label lblC1IncreasedVulnerable = new Label("Input community "+comNumb+" co-morbility death multiplier: ");
		Label lblC1InfectionMultiplier = new Label("Input community "+comNumb+" increased chance of infection: ");
				
		//setup text fields
		c1Pop = new TextField();
		C1VacPer = new TextField();
		C1VacEff = new TextField();
		C1AOV = new TextField();
		C1ADM = new TextField();
		C1PV= new TextField();
		C1IV= new TextField();
		C1IM= new TextField();
		C1Inf= new TextField();
		
		//inputDate = new DatePicker();
		
		//initialise create profile button
		btnCreateMap = new Button(
				"Create Map\n"  + "warning: will reset simulation");
		

		//add controls and labels to container

		this.add(lblC1Pop, 0, 1);
		this.add(c1Pop, 1, 1);
		
		this.add(lblC1Vaccinated, 0, 2);
		this.add(C1VacPer, 1, 2);

		this.add(lblC1VacEffect, 0, 3);
		this.add(C1VacEff, 1, 3);
		
		this.add(lblC1AgeOfVulnerable, 0, 4);
		this.add(C1AOV, 1, 4);
		
		this.add(lblC1AOVDeathMultiplier, 0, 5);
		this.add(C1ADM, 1, 5);
		
		this.add(lblC1PercentVulnerable, 0, 6);
		this.add(C1PV, 1, 6);
		
		this.add(lblC1IncreasedVulnerable, 0, 7);
		this.add(C1IV, 1, 7);
		
		this.add(lblC1InfectionMultiplier, 0, 8);
		this.add(C1IM, 1, 8);
		
		this.add(lblC1Infec, 0, 9);
		this.add(C1Inf, 1, 9);
		
		this.add(btnCreateMap, 0, 10);
	}
	
	public String getC1Pop() {
		return c1Pop.getText();
	}
	
	public String getC1VacPer() {
		return C1VacPer.getText();
	}

	public String getC1VacEff() {
		return C1VacEff.getText();
	}
	
	public String getC1AOV() {
		return C1AOV.getText();
	}
	
	public String getC1ADM() {
		return C1ADM.getText();
	}

	public String getC1PV() {
		return C1PV.getText();
	}
	
	public String getC1IV() {
		return C1IV.getText();
	}
	public String getC1IM() {
		return C1IM.getText();
	}
	public String getC1Inf() {
		return C1Inf.getText();
	}
	
	
	// method to attach the create map button event handler
	public void addComDataInputHandler(EventHandler<ActionEvent> handler) {
		btnCreateMap.setOnAction(handler);
	}
}
