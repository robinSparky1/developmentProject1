package view;

import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.ListView;
import javafx.scene.layout.GridPane;

public class GraphPane extends GridPane {
	private ObservableList<String> op1;
	private ListView<String>output1;
	private Object stage;
	private XYChart.Series totInf;
	private Series c1Inf;
	private Series c2Inf;
	private Series c3Inf;
	private Series c4Inf;
	private Series totd;
	private Series c1d;
	private Series c2d;
	private Series c3d;
	private Series c4d;
	public GraphPane() {
		final NumberAxis xAxis = new NumberAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Day");
        //creating the chart
        final LineChart<Number,Number> lineChart =new LineChart<Number,Number>(xAxis,yAxis);
        lineChart.setTitle("Infectious Disease simualtion");
        //defining a series
        totInf = new XYChart.Series();
        totInf.setName("total Infected");
        c1Inf = new XYChart.Series();
        c1Inf.setName("community1 infected");
        c2Inf = new XYChart.Series();
        c2Inf.setName("community1 infected");
        c3Inf = new XYChart.Series();
        c3Inf.setName("community1 infected");
        c4Inf = new XYChart.Series();
        c4Inf.setName("community1 infected");
        
        this.add(lineChart, 1, 1);
        
        lineChart.getData().add(totInf);
        lineChart.getData().add(c1Inf);
        lineChart.getData().add(c2Inf);
        lineChart.getData().add(c3Inf);
        lineChart.getData().add(c4Inf);

		final NumberAxis dxAxis = new NumberAxis();
        final NumberAxis dyAxis = new NumberAxis();
        dxAxis.setLabel("Day");
        //creating the chart
        final LineChart<Number,Number> DeathChart =new LineChart<Number,Number>(xAxis,yAxis);
        DeathChart.setTitle("Infectious Disease simualtion");
        //defining a series
        totd = new XYChart.Series();
        totd.setName("total Dead");
        c1d = new XYChart.Series();
        c1d.setName("community1 Dead");
        c2d = new XYChart.Series();
        c2d.setName("community1 Dead");
        c3d = new XYChart.Series();
        c3d.setName("community1 Dead");
        c4d = new XYChart.Series();
        c4d.setName("community1 Dead");
        
        this.add(DeathChart, 2, 1);
        
        DeathChart.getData().add(totd);
        DeathChart.getData().add(c1d);
        DeathChart.getData().add(c2d);
        DeathChart.getData().add(c3d);
        DeathChart.getData().add(c4d);
	}
	
	public void addToTotInf(int x, int y) {
		totInf.getData().add(new XYChart.Data(x, y));
	}
	public void addToc1Inf(int x, int y) {
		c1Inf.getData().add(new XYChart.Data(x, y));
	}
	public void addToc2Inf(int x, int y) {
		c2Inf.getData().add(new XYChart.Data(x, y));
	}
	public void addToc3Inf(int x, int y) {
		c3Inf.getData().add(new XYChart.Data(x, y));
	}
	public void addToc4Inf(int x, int y) {
		c4Inf.getData().add(new XYChart.Data(x, y));
	}
	
	public void addToTotd(int x, int y) {
		totd.getData().add(new XYChart.Data(x, y));
	}
	public void addToc1d(int x, int y) {
		c1d.getData().add(new XYChart.Data(x, y));
	}
	public void addToc2d(int x, int y) {
		c2d.getData().add(new XYChart.Data(x, y));
	}
	public void addToc3d(int x, int y) {
		c3d.getData().add(new XYChart.Data(x, y));
	}
	public void addToc4d(int x, int y) {
		c4d.getData().add(new XYChart.Data(x, y));
	}
}
