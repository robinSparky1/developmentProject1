package view;

import javafx.scene.control.Tab;
import java.util.ArrayList;
import java.util.List;

import javafx.scene.control.TabPane;
import javafx.scene.control.TabPane.TabClosingPolicy;
import javafx.scene.layout.BorderPane;

public class InfectionSimulatorRootPane extends BorderPane {
	private TabPane tp;
	private int comNumb;
	private DiseaseDataInputPane idd;
	private CommunityDataInput cdi,cdi2,cdi3,cdi4;
	private OutputOnePane out;
	private ArrayList<CommunityDataInput> MoreComIn;
	private List<Tab> MoreComInTab;
	private TravelDataInputPane tdi;
	private InfectiousDiseaseSimulatorMenuBar idsmb;
	private PolicyDataInputPane pdi;
	private GraphPane gp;

	public InfectionSimulatorRootPane() {
		MoreComIn=new ArrayList<CommunityDataInput>();
		comNumb=1;
		// create tab pane and disable tabs from being closed
		tp = new TabPane();
		tp.setTabClosingPolicy(TabClosingPolicy.UNAVAILABLE);

		// create panes
		idd = new DiseaseDataInputPane();
		out=new OutputOnePane();
		cdi=new CommunityDataInput(1);
		cdi2=new CommunityDataInput(2);
		cdi3=new CommunityDataInput(3);
		cdi4=new CommunityDataInput(4);
		tdi=new TravelDataInputPane();
		pdi= new  PolicyDataInputPane();
		gp=new GraphPane();

		// create tabs with panes added
		Tab t1 = new Tab("Imput Disease Data", idd);
		Tab t21 = new Tab("community 1 data input", cdi);
		Tab t22 = new Tab("community 2 data input", cdi2);
		Tab t23 = new Tab("community 3 data input", cdi3);
		Tab t24 = new Tab("community 4 data input", cdi4);
		Tab t4 = new Tab("Output", out);
		Tab t3 = new Tab("travel data input",tdi);
		Tab t5 = new Tab("Policy data Input",pdi);
		Tab t6 = new Tab("Graphed Results",gp);

		// add tabs to tab pane
		tp.getTabs().addAll(t1,t21,t22,t23,t24,t3,t4,t6,t5);

		// create menu bar
		idsmb = new InfectiousDiseaseSimulatorMenuBar();

		// add menu bar and tab pane to this root pane
		this.setTop(idsmb);
		this.setCenter(tp);
	}

	// method to allow the controller to change tabs
	public void changeTab(int index) {
		tp.getSelectionModel().select(index);
	}
	
	public GraphPane getGP() {
		return gp;
	}
	
	public PolicyDataInputPane getPDI() {
		return pdi;
	}
	public TravelDataInputPane getTDI() {
		return tdi;
	}
	public DiseaseDataInputPane getDDID() {
		return idd;
	}
	public OutputOnePane getOOP() {
		return out;
	}
	public CommunityDataInput getCDI() {
		return cdi;
	}
	public CommunityDataInput getCDI2() {
		return cdi2;
	}
	public CommunityDataInput getCDI3() {
		return cdi3;
	}
	public CommunityDataInput getCDI4() {
		return cdi4;
	}
	public InfectiousDiseaseSimulatorMenuBar getIDSMB() {
		return idsmb;
	}
}
