package view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;

public class TravelDataInputPane extends GridPane {
	private TextField C1ToC2;
	private TextField C1ToC4;
	private TextField C1ToC3;
	private TextField C2ToC1;
	private Button btnCreateLinks;

	public TravelDataInputPane() {
		// styling
		this.setVgap(15);
		this.setHgap(20);
		this.setAlignment(Pos.CENTER);

		ColumnConstraints column0 = new ColumnConstraints();
		column0.setHalignment(HPos.RIGHT);

		this.getColumnConstraints().addAll(column0);

		// create labels
		Label lblC1ToC2 = new Label("probability of a infection spreading from 1");
		Label lblC1ToC3 = new Label("probability of a infection spreading from 2");
		Label lblC1ToC4 = new Label("probability of a infection spreading from 3");
		Label lblC2ToC1 = new Label("probability of a infection spreading from 4");

		// setup text fields
		C1ToC2 = new TextField();
		C1ToC3 = new TextField();
		C1ToC4 = new TextField();
		C2ToC1 = new TextField();

		// initialise create profile button
		btnCreateLinks = new Button("Create Travel Links");
		
		//add controls and labels to container
		this.add(lblC1ToC2, 0, 1);
		this.add(C1ToC2, 1, 1);
		
		this.add(lblC1ToC3, 0, 2);
		this.add(C1ToC3, 1, 2);

		this.add(lblC1ToC4, 0, 3);
		this.add(C1ToC4, 1, 3);
		
		this.add(lblC2ToC1, 0, 4);
		this.add(C2ToC1, 1, 4);
		
		/*
		this.add(lblC2ToC3, 0, 5);
		this.add(C2ToC3, 1, 5);
		
		this.add(lblC2ToC4, 0, 6);
		this.add(C2ToC4, 1, 6);

		this.add(lblC3ToC1, 0, 7);
		this.add(C3ToC1, 1, 7);
		
		this.add(lblC3ToC2, 0, 8);
		this.add(C3ToC2, 1, 8);

		this.add(lblC3ToC4, 0, 9);
		this.add(C3ToC4, 1, 9);
		
		this.add(lblC4ToC1, 0, 10);
		this.add(C4ToC1, 1, 10);

		this.add(lblC4ToC2, 0, 11);
		this.add(C4ToC2, 1, 11);
		
		this.add(lblC4ToC3, 0, 12);
		this.add(C4ToC3, 1, 12);
		*/
		this.add(btnCreateLinks, 0, 13);
		
	}
	
	public String getC1toC2() {return C1ToC2.getText();}
	public String getC1toC3() {return C1ToC3.getText();}
	public String getC1toC4() {return C1ToC4.getText();}
	public String getC2toC1() {return C2ToC1.getText();}
	/*
	public String getC2toC3() {return C2ToC3.getText();}
	public String getC2toC4() {return C2ToC4.getText();}
	public String getC3toC1() {return C3ToC1.getText();}
	public String getC3toC2() {return C3ToC2.getText();}
	public String getC3toC4() {return C3ToC4.getText();}
	public String getC4toC1() {return C4ToC1.getText();}
	public String getC4toC2() {return C4ToC2.getText();}
	public String getC4toC3() {return C4ToC3.getText();}
	*/
	
	public void addCreateLinksHandler(EventHandler<ActionEvent> handler) {
		btnCreateLinks.setOnAction(handler);
	}
}
