package Main;
import model.map;

public class AppPrototype {//OLD CODE DO NOT USE
	public static void main(String[] args) {
		System.out.println("app");
		map theMap=new map();
		while (theMap.getNumbInfect()>0) {
			theMap.nextDay(30,90);
			System.out.println(theMap.getNumbInfect());
		}
	}
}
