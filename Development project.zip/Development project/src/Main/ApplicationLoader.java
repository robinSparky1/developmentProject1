package Main;

import controller.InfectionSimulatorControler;
//import controller.InfectionSimulatorRootPane;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.community;
import model.map;
import view.InfectionSimulatorRootPane;

public class ApplicationLoader extends Application{
	private  InfectionSimulatorRootPane view;
	
	@Override
	public void init() {
		//create view and model and pass their references to the controller
		view = new  InfectionSimulatorRootPane();
		map model = new map();
		new InfectionSimulatorControler(view,model);
	}

	
	@Override
	public void start(Stage stage) throws Exception {
		//sets min width and height for the stage window
		stage.setMinWidth(530); 
		stage.setMinHeight(500);
		stage.setWidth(1000);
		stage.setHeight(700);
		
		stage.setTitle("infectious disease simulator");
		stage.setScene(new Scene(view));
		stage.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
