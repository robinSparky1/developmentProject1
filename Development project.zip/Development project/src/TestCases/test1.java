package TestCases;
import model.map;
import model.person;
import model.community;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class test1 {

	@Test
	void test1CreatePerson() {
		person aPerson=new person();
		assertEquals(40, aPerson.getAge());
	}
	@Test
	void test2CreateCommunity() {
		community location1=new community();
		assertEquals(1000, location1.getPeople().size());
	}
	@Test
	void test3CreateMap() {
		map map1=new map();
		assertEquals(1, map1.getComies().size());
	}
	@Test
	void test4SetAge() {
		person aPerson=new person();
		aPerson.setAge(69);
		assertEquals(69, aPerson.getAge());
	}
	@Test
	void test5SetImmunity() {
		person aPerson=new person();
		aPerson.setImmunity(69);
		assertEquals(69, aPerson.getImmune());
	}
	@Test
	void test6SetMorbid() {
		person aPerson=new person();
		aPerson.setMorbid(44);
		assertEquals(44, aPerson.getMorbid());
	}
	@Test
	void test7SetAlive() {
		person aPerson=new person();
		aPerson.setAlive(false);
		assertFalse(aPerson.getAlive());
	}
	@Test
	void test8SetInfect() {
		person aPerson=new person();
		aPerson.setInfect(10);
		assertEquals(10, aPerson.getDaysLeft());
		assertEquals(100, aPerson.getImmune());
	}
	@Test
	void test9NextDay1() {
		person aPerson=new person();
		int temp=0;
		aPerson.setInfect(10);
		assertEquals(10, aPerson.getDaysLeft());
		assertEquals(100, aPerson.getImmune());
		temp+=aPerson.nextDay(30,90);
		assertEquals(9, aPerson.getDaysLeft());
		assertEquals(100, aPerson.getImmune());
		assertTrue(temp>=0);
	}
	@Test
	void test11NextDay1() {
		person aPerson=new person();
		int temp=0;
		assertEquals(0, aPerson.getDaysLeft());
		assertEquals(0, aPerson.getImmune());
		temp+=aPerson.nextDay(30,90);
		assertEquals(0, aPerson.getDaysLeft());
		assertEquals(0, aPerson.getImmune());
		assertTrue(temp==0);
	}
	@Test
	void test12recovery() {
		person aPerson=new person();
		int temp=0;
		aPerson.setInfect(1);
		assertEquals(1, aPerson.getDaysLeft());
		assertEquals(100, aPerson.getImmune());
		temp+=aPerson.nextDay(30,90);
		assertEquals(0, aPerson.getDaysLeft());
		assertEquals(90, aPerson.getImmune());
		assertTrue(temp>=0);
	}
	
	@Test
	void test13getInfectedCom() {
		community location1=new community();
		assertEquals(1, location1.getInfected());
	}
	@Test
	void test14NextDayCom() {
		community location1=new community();
		assertEquals(1, location1.getInfected());
		location1.nextDay(30,90);
		assertTrue(1<=location1.getInfected());
		
	}
	
	@Test
	void test15GetInfectedMap() {
		map map1=new map();
		assertEquals(1, map1.getNumbInfect());
	}
	@Test
	void test16NextDayMap() {
		map map1=new map();
		assertEquals(1, map1.getNumbInfect());
		map1.nextDay(30,90);
		assertTrue(1<=map1.getNumbInfect());
	}
	
}
